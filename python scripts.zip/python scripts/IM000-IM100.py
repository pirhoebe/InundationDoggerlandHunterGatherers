## inundation model 000 Bathy x ESL and 100 pDEM x ESL
## Pir Hoebe - p.w.hoebe@rug.nl
import os
import numpy as np
import pandas as pd

## Define model name
modelname='IM000' # change to IM100 for paleoDEMxESL
## Define directories
data_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'input folder')
output_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'output folder')

## 1 Prepare DEM layer
DEM = 'BATHY' # change to 'paleoDEM' for IM100
DEMlayer = DEM+'@1'
DEMfile = DEM+'.tif'
DEMpath = os.path.join(data_dir, DEMfile)

## 2 Prepare sea level file
ESLfile = 'ESL models.csv'
ESLdir = os.path.join(data_dir, ESLfile)
ESL = pd.read_csv(ESLdir)
ESL['calBP']=ESL['calBP'].astype(str)
## choose 'Lambeck2014NS or 'Bradley2016' for model
model='Lambeck2014NS'
ESLL = ESL[['calBP', model]]

## 3 Prepare time slices 
## Note: these should correspond to the values in the ESLfile calBP column
Tslices= np.arange(-12000, -6750, 250)
Tslices= np.ndarray.tolist(Tslices)
Tslices= [str(x) for x in Tslices]
SLLayers = list(t for t in Tslices)

## messages:
print(20*'#'+'- Calculating ',modelname,': ',DEM,' * ',model,' -'+ 20*'#')
print('Calculating Inundation Models with the following SLLs:', 
SLLayers)
print('WARNING: QGIS may freeze while processing. Do not close application')
print('Coast models are saved here:\n',output_dir)

## Define a peat and tidal zone
P='2'
T='2'

## Simple timeslice specific DEM output 
for x in SLLayers:
    print(x)
    i = str(SLLayers.index(x)+1)
    Mfile=modelname+' ('+ i +') '+ x+'.tif'
    IMfile = os.path.join(output_dir, Mfile)
    print('saving:', IMfile)
    myDEM= '\"'+DEMlayer+'\"'
    ESLdepth= ESLL.loc[ESLL['calBP']==x, model]
    sealevel=ESLdepth.values[0]
    sealevel=sealevel.astype(str)
    DEMresult=myDEM
    modelExpr = '\''+DEMresult+' - '+sealevel+'\''
    results = processing.runAndLoadResults("qgis:rastercalculator", 
    {'EXPRESSION':modelExpr,
    'LAYERS': DEMpath,
    'CELLSIZE':5000, ## choose desired cellsize in meters
    'EXTENT': 'DEM extent', ## copy the DEM's extent
    'CRS':QgsCoordinateReferenceSystem('CRS'),## copy the DEM's CRS
    'OUTPUT':IMfile})

## categorised height above relative sea level model output 
for x in SLLayers:
    print(x)
    i = str(SLLayers.index(x)+1)
    Mfile=modelname+' ('+ i +') '+ x+'.tif'
    IMfile = os.path.join(output_dir, Mfile)
    print('saving:', IMfile)
    myDEM= '\"'+DEMlayer+'\"'
    ESLdepth= ESLL.loc[ESLL['calBP']==x, model]
    sealevel=ESLdepth.values[0]
    sealevel=sealevel.astype(str)
    DEMresult=myDEM
    modelExpr ='((' +DEMresult+') < ('+sealevel+'-'+T+')) * 1 + ((('\
        +DEMresult+') >= ('+sealevel+'-'+T+')) AND ((' +DEMresult+') < '+sealevel+')) * 2 + ((('\
        +DEMresult+') >= '+sealevel+') AND ((' +DEMresult+') < ('+sealevel+'+'+P+'))) * 3 + ((('\
        +DEMresult+') >= ('+sealevel+'+'+P+')) AND ('+DEMresult+' < ('+sealevel+'+20 ))) * 4 + (('\
        +DEMresult+' >= ('+sealevel+'+20)) AND ('+DEMresult+' < ('+sealevel+'+50))) * 5 + (('\
        +DEMresult+' >= ('+sealevel+'+50)) AND ('+DEMresult+' < ('+sealevel+'+100))) * 6 + (('\
        +DEMresult+' >= ('+sealevel+'+100)) AND ('+DEMresult+' < ('+sealevel+'+250))) * 7 + ('\
        +DEMresult+' >= ('+sealevel+'+250)) * 8'
    results = processing.runAndLoadResults("qgis:rastercalculator", 
    {'EXPRESSION':modelExpr,
    'LAYERS': DEMpath,
    'CELLSIZE':5000, ## choose desired cellsize in meters
    'EXTENT': 'DEM extent', ## copy the DEM's extent
    'CRS':QgsCoordinateReferenceSystem('CRS'),## copy the DEM's CRS
    'OUTPUT':IMfile})
