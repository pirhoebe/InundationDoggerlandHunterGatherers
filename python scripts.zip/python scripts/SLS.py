##### CREATE A BATCH OF SEA LEVEL LAYERS BASED ON GIA MODEL OUTPUT LOCATIONS:
## Pir Hoebe - p.w.hoebe@rug.nl
import os
import numpy as np

## Define directories
data_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'input folder')
output_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'output folder')

## 1 Prepare GIA points layer:
filename = 'SLL.shp'
SLdata = os.path.join(data_dir, filename)

## 2 Prepare time slices
## Note: these should correspond to the SLL.shp column names
Tslices= np.arange(-12000, -6750, 250)
Tslices= np.ndarray.tolist(Tslices)
SLLayers= [str(x) for x in Tslices]

## messages:
print('Interpolating Sealevel layers (SLL) for the following timeslices:', 
SLLayers)
print('QGIS may freeze while processing. Do not close application')
print('SLLs are saved here:',data_dir)

#### PROCESSING: 
for x in SLLayers:
    Tslice=x
    SLLfile = 'SLL '+ x +'.sdat'
    print(Tslice)
    print(SLLsave)
    SLLsave = os.path.join(output_dir, SLLfile)
    results = processing.runAndLoadResults("saga:thinplatespline", 
    {'SHAPES': SLdata,
    'FIELD': Tslice,
    'EXTENT':'Extent', ## choose desired extent here
    'TARGET_USER_SIZE':5000, ## choose desired cell size in meteres
    'TARGET_OUT_GRID': SLLsave,
    ## interpolation parameters:
    'REGULARISATION':0.0001,
    'SEARCH_RANGE':1,
    'SEARCH_RADIUS':1000,
    'SEARCH_POINTS_ALL':1,
    'SEARCH_POINTS_MIN':16,
    'SEARCH_POINTS_MAX':20,
    'SEARCH_DIRECTION':0})
    
   