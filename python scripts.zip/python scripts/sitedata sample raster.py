## Pir Hoebe - p.w.hoebe@rug.nl
modelname='IM3-1'
import os
import numpy as np
import pandas as pd

sitedata = os.path.join(os.path.expanduser('~'), 'OneDrive - University of Groningen','Documents', 
'Archeologie PhD', '- DATA ANALYSIS','QGIS','paleoDEM', 'sites_PH24.shp')
raster_dir = os.path.join(os.path.expanduser('~'), 'OneDrive - University of Groningen','Documents', 
'Archeologie PhD', '- DATA ANALYSIS','QGIS','paleoDEM', 'Final', 'output', '3-1 pDEM+BGS+P GIA')


layer_count = 37
Tslices= np.arange(-16, -6.75, 0.25)
Tslices= np.around(Tslices, decimals=2, out=None)
Tslices= np.ndarray.tolist(Tslices)
print(Tslices)
SLLayers= ["{:.2f}".format(x) for x in Tslices]


for x in SLLayers:
    print('Timeslice:', x)
    y = SLLayers.index(x)
    Tfile = x.replace('.', '-')
    i = str(SLLayers.index(x)+1)
    Mfile=modelname+' ('+ i +') '+ Tfile+'.tif'
    IMfile = os.path.join(raster_dir, Mfile)
    processing.run("native:rastersampling", 
        {'INPUT':sitedata,
        'RASTERCOPY':IMfile,
        'COLUMN_PREFIX':Tfile,
        'OUTPUT':'TEMPORARY_OUTPUT'})