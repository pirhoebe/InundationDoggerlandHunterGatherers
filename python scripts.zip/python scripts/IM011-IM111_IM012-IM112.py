## inundation model 011 Bathy+VLM - SSL and 111 pDEM+VLM - SSL
## inundation model 012 Bathy+VLM+p - SSL and 112 pDEM+VLM+p - SSL
## Pir Hoebe - p.w.hoebe@rug.nl

## Define model name
modelname='IM112' # paleoDEM+VLM+p-SLL change modelname to IM111 for paleoDEM+VLM-SLL, 
# or change to IM011 (Bathy+VLM-SLL) or IM012 (Bathy+VLM+p-SLL)
import os
import numpy as np
import pandas as pd

## Define directories
data_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'input folder')
output_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'output folder')

## 1 Prepare DEM layer
DEM = 'paleoDEM' # change to 'Bathy' for IM011 or IM012
DEMlayer = DEM+'@1'
DEMfile = DEM+'.tif'
DEMpath = os.path.join(data_dir, DEMfile)

## 2 Prepare VLM layer
VLM = 'VLM250 RA'
VLMlayer = VLM+'@1'
VLMfile = VLMlayer+'.tif'
VLMpath = os.path.join(data_dir, VLMfile)

iVLMfile= 'VLM multiplier.csv'
iVLMpath=VLMpath = os.path.join(data_dir, iVLMfile)
iVLM = pd.read_csv(iVLMpath)
iVLM = iVLM[['calBP', 'iVLM']]


## 3 Prepare peat csv
## remove this block for IM011 or IM111
peatfile = 'peat.csv'
peatdir = os.path.join(data_dir, peatfile)
peat = pd.read_csv(peatdir)


## 3 Prepare time slices 
## Note: these should correspond to the values of the SLL layer names
Tslices= np.arange(-12000, -6750, 250)
Tslices= np.ndarray.tolist(Tslices)
Tslices= [str(x) for x in Tslices]
SLLayers = list(t for t in Tslices)

## messages:
print(20*'#'+'- Calculating ',modelname,': ',DEM,' * SLL -'+ 20*'#')
print('Calculating Inundation Models with the following SLLs:', SLLayers)
print('WARNING: QGIS may freeze while processing. Do not close application')
print('inundation models are saved here:\n',output_dir)

P='2'
T='3'

## categorised height above relative sea level model output 
for x in SLLayers:
  print('Timeslice:', x)
y = SLLayers.index(x) 
i = str(SLLayers.index(x)+1) # because python indexation starts at 0
Mfile=modelname+' ('+ i +') '+ x+'.tif'
IMfile = os.path.join(output_dir, Mfile)
print('saving:',IMfile)
myDEM= '\"'+DEMlayer+'\"'
myVLM= '\"'+VLMlayer+'\"'
n= iVLM.loc[iVLM['calBP']==x, 'iVLM']
n=n.astype(str)
print('VLM multiplier:', n)
c=str(peat.loc[y, 'p']) ## remove this line for IM011 or IM111
sealevel= '\"SLL5 '+x+'@1\"'
print('Sealevel layer:', sealevel)
DEMresult=myDEM+'-('+n+'*'+myVLM+')'
modelExpr ='(('+DEMresult+'+'+c+') < ('+sealevel+'-'+T+')) * 1 + ((('\
    +DEMresult+'+'+c+') >= ('+sealevel+'-'+T+')) AND (('+DEMresult+'+'+c+') < '+sealevel+')) * 2 + ((('\
    +DEMresult+'+'+c+') >= '+sealevel+') AND (('+DEMresult+'+'+c+') < ('+sealevel+'+'+P+'))) * 3 + ((('\
    +DEMresult+'+'+c+') >= ('+sealevel+'+'+P+')) AND ('+DEMresult+' < ('+sealevel+'+20 ))) * 4 + (('\
    +DEMresult+' >= ('+sealevel+'+20)) AND ('+DEMresult+' < ('+sealevel+'+50))) * 5 + (('\
    +DEMresult+' >= ('+sealevel+'+50)) AND ('+DEMresult+' < ('+sealevel+'+100))) * 6 + (('\
    +DEMresult+' >= ('+sealevel+'+100)) AND ('+DEMresult+' < ('+sealevel+'+250))) * 7 + ('\
    +DEMresult+' >= ('+sealevel+'+250)) * 8'
results = processing.runAndLoadResults("qgis:rastercalculator", 
{'EXPRESSION':modelExpr,
'LAYERS': DEMpath,
'CELLSIZE':5000, ## choose desired cellsize in meters
'EXTENT': 'DEM extent', ## copy the DEM's extent
'CRS':QgsCoordinateReferenceSystem('CRS'),## copy the DEM's CRS
'OUTPUT':IMfile})