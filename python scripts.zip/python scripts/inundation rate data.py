## inundation rate raster cell count
## Pir Hoebe - p.w.hoebe@rug.nl
import os
import numpy as np
import csv

## Define model name
modelname='IM112'

## Define directories
data_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'input folder')
output_dir = os.path.join(os.path.expanduser('~'), 'user','Documents', 'output folder')


## 1 Prepare time slices 
Tslices= np.arange(-12000, -6750, 250)
Tslices= np.ndarray.tolist(Tslices)
Tslices= [str(x) for x in Tslices]
SLLayers = list(t for t in Tslices)

print(20 * '#' + '- Calculating area per landscape category -' + 20 * '#')
print('Calculating coast models with the following timeslices:', SLLayers)

## Output CSV file path
outputfile=modelname+ ' combined_results.csv'
output_csv = os.path.join(output_dir, outputfile)
header = ['IMfile', 'value', 'count', 'm2']
with open(output_csv, 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(header)

## Process each SLLayer
for x in SLLayers:
    i = str(SLLayers.index(x) + 1)
    x = x.replace('.', '-')
    IMlayer = modelname+' (' + i + ') ' + x + '.tif' 
    IMfile = os.path.join(data_dir, IMlayer)
    arealayer = 'area (' + i + ') ' + x + '.csv'
    print(arealayer)
    areafile = os.path.join(output_dir, arealayer)
    results = processing.run("native:rasterlayeruniquevaluesreport",
                             {'INPUT': IMfile,
                              'BAND': 1,
                              'OUTPUT_HTML_FILE': None,
                              'OUTPUT_TABLE': areafile})

    # Read the areafile and append the data to the output CSV file
    with open(areafile, 'r') as input_file:
        reader = csv.reader(input_file)
        next(reader)  # Skip the header row
        with open(output_csv, 'a', newline='') as output_file:
            writer = csv.writer(output_file)
            for row in reader:
                writer.writerow([IMfile] + row)  # Append IMfile to each row
