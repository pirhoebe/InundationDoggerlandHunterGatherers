###############################################################################
#### 3 Spatial Analysis ####
###############################################################################
# install and read relevant libraries
source(file="R scripts/read libraries.R")

sites_full <-  unique(data.frame(id=data_full$site_id, 
                                 lat=data_full$wgslat, 
                                 lon=data_full$wgslon, 
                                 name=data_full$sitename,
                                 country=data_full$country))
sites_full <- sites_full[order(sites_full$country, sites_full$name),]
sites_full$id <- 1:length(sites_full$id)
for (n in sites_full$name){
  print(n)
  data_full$site_id[data_full$sitename==n] <- sites_full$id[sites_full$name==n]
  data_full.cal$site_id[data_full.cal$sitename==n] <- sites_full$id[sites_full$name==n]
  # data_full$site_id <-  sites_full$id
  }

path <- "data/sheets/sites24 final.xlsx"
write.xlsx(sites_full,  file=path)
##check ids
coords=data.frame(x=sites_full$lon, y=sites_full$lat)
coords=as.matrix(coords)
dimnames(coords) <- list(c(sites_full$id), c("x", "y"))


row.names(sites_full) <- sites_full$id


sbox=matrix(c(min(sites_full$lon),
            min(sites_full$lat),
            max(sites_full$lon),
            max(sites_full$lat)),
            nrow=2, 
            ncol=2)

dimnames(sbox) <- list(c("x", "y"), c("min", "max"))
sites <- SpatialPointsDataFrame(coords=coords,
                                data=sites_full,
                                proj4string=CRS("+init=epsg:4326"), 
                                bbox = sbox)


###############################################################################
# 250 y breaks
###############################################################################

breaks <- seq(12000, 6750, -250)
timeRange <- c(12000, 6750)
data_full.spd <- spd(x = data_full.cal,
                     bins=data_full$bins,
                     timeRange = timeRange)
###############################################################################
# plot
###############################################################################
par(mfrow=c(1,1), mar=c(1,1,1,5), las=0)


plot(spd2rc(data_full.spd,
            breaks = breaks))

data_full.spd2rc<- spd2rc(data_full.spd,
       breaks = breaks)
plot(data_full.spd2rc)

###############################################################################



distmat_full <- spDists(x=cbind(sites_full$lon,sites_full$lat),
                        y=cbind(sites_full$lon,sites_full$lat))

sp_wt_full<- spweights(distmat=distmat_full, h = 100, kernel = "gaussian")

###############################################################################
## cf Crema et al.2017
###############################################################################

spat_full <- sptest(calDates=data_full.cal,
                    bins=data_full$bins,
                    timeRange=timeRange, 
                    locations=sites,
                    datenormalised = FALSE,
                    spatialweights=sp_wt_full,
                    permute="locations",
                    nsim=100,
                    breaks=breaks,
                    ncores=3,
                    verbose=FALSE) 
###############################################################################
# next steps
###############################################################################
if (!require(rnaturalearth)) install.packages("rnaturalearth")
if (!require(devtools)) install.packages("devtools")
if (!require(rlang)) install.packages("rlang")


devtools::install_github("ropensci/rnaturalearthhires")

win  <- st_geometry(ne_countries(continent = 'europe',scale=10,returnclass='sf'))
#extract bounding coordinates of the site distribution

xrange <- st_bbox(sites)[c(1,3)]
yrange <- st_bbox(sites)[c(2,4)]

for (i in 19:20){
  timeframe1=paste(breaks[i-1]/1000,"-",breaks[i]/1000, sep="")
  timeframe2=paste(breaks[i]/1000,"-",breaks[i+1]/1000, sep="")
  filename=paste("SPT 2 (",i-1,") ",timeframe1, " to ", timeframe2, " calBP.png", sep="")
  print(filename)
  png(file=filename,
      width=2000, height=1200)
## Spatial Permutation Test for Transition 4
par(mar=c(1,1,4,1),mfrow=c(1,2), cex=5)
# Plot function should have the option to either use default or return an sf object
plot(win,
     col="white", 
     border="black",
     xlim=xrange, 
     ylim=yrange, 
     main=paste(timeframe1, " to ", timeframe2," calBP \n (Test Results)", sep=""),
     cex.main=0.7)
plot(spat_full,
     index=i, 
     option="test", 
     add=TRUE, 
     legend=TRUE, 
     legSize=0.4, 
     location="bottomleft")

## Geometric Growth Rate for Transition 4
plot(win,
     col="white", 
     border="black", 
     xlim=xrange, ylim=yrange, 
     main=paste(timeframe1, " to ", timeframe2," calBP \n (Growth Rate)", sep=""),
     cex.main=0.7)
plot(spat_full,
     index=i, 
     option="raw", 
     add=TRUE,
     breakRange=c(-0.005,0.005),
     breakLength=7,
     rd=5, 
     legend=TRUE,
     legSize=0.4,
     location="bottomleft")
dev.off()
}
beep()

