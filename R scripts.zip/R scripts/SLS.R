## RSL model checking and editing

# install and load packages
if (!require(rnaturalearth)) install.packages("rnaturalearth")
if(!"rnaturalearth" %in% (.packages())){library(rnaturalearth)} else {message(paste("package is already attached"))}
if (!require(rnaturalearthdata)) install.packages("rnaturalearthdata")
if(!"rnaturalearthdata" %in% (.packages())){library(rnaturalearthdata)} else {message(paste("package is already attached"))}
if (!require(readxl)) install.packages("readxl")
if(!"readxl" %in% (.packages())){library(readxl)} else {message(paste("package is already attached"))}
if (!require(openxlsx)) install.packages("openxlsx")
if(!"openxlsx" %in% (.packages())){library(openxlsx)} else {message(paste("package is already attached"))}
if (!require(ggplot2)) install.packages("ggplot2")
if(!"ggplot2" %in% (.packages())){library(ggplot2)} else {message(paste("package is already attached"))}
if (!require(dplyr)) install.packages("dplyr")
if(!"dplyr" %in% (.packages())){library(dplyr)} else {message(paste("package is already attached"))}


theme_set(theme_bw())
world <- ne_countries(scale="medium", returnclass = "sf")
class(world)

SLS <- read_excel("data/sheets/RSL models.xlsx")
ESL <- read_excel("data/sheets/ESL models.xlsx")


###################
#### DATA prep ####
###################
### seperate GIA and SLIP datasets
GIA=SLS[SLS$type== "GIA model",]
SLIP=SLS[!SLS$type== "GIA model",]

#create color scale based on xy coordinates and id
GIAid <- SLS%>% select(id, type,wgs_lat, wgs_lon)
GIAid <- unique(GIAid)
GIAid$r=GIAid$wgs_lon+min(GIAid$wgs_lon)*-1
GIAid$r=(GIAid$r/max(GIAid$r))
GIAid$g=GIAid$wgs_lat+min(GIAid$wgs_lat)*-1
GIAid$g=1-(GIAid$g/max(GIAid$g))
GIAid$b <- NA_real_
GIAid$t <- 1
GIAids <- data.frame(id=unique(round(GIAid$id,0)), nr=1:length(unique(round(GIAid$id,0))))
GIAid$gia <- round(GIAid$id,0)
GIAid <- left_join(GIAid, GIAids, by=c("gia"="id"))
GIAid$b[GIAid$gia<25] <- 1-GIAid$nr[GIAid$gia<25]/25
GIAid$b[GIAid$gia>25] <- (GIAid$nr[GIAid$gia>25]-24)/length(GIAid$nr[GIAid$gia>25])

GIAid <- GIAid[order(GIAid$id),]
GIAid$id <- factor(GIAid$id, levels=GIAid$id)

# GIAid$colour=rgb(GIAid$r,GIAid$g, GIAid$b, GIAid$t)

colorscale <- rgb(GIAid$r,GIAid$g, GIAid$b, GIAid$t)
names(colorscale) <-GIAid$id 
colorscale

GIA=SLS[SLS$type== "GIA model",]
SLIP=SLS[!SLS$type== "GIA model",]

#################################
#### PLOT SLcurves and SLIPs ####
#################################


# Figure 4a
#################################
ggplot()+geom_sf(data=world)+coord_sf(crs="+init=epsg:4326",
                                      xlim=c(-2.5, 9.5), ylim=c(50.5,56))+
  geom_point(aes(x=GIAid$wgs_lat, 
                 y=GIAid$wgs_lon,
                 shape=GIAid$type,
                 group=GIAid$id, 
                 color=GIAid$id), cex=3)+
  scale_colour_manual(values=colorscale)+
  geom_text(aes(x=GIAid$wgs_lat, 
                y=GIAid$wgs_lon,
                label=GIAid$id,
                vjust=1,
                hjust=1.5))+
  labs(x="Latitude",y="Longitude", color="GIA id", shape= "type")

# create interpolated GIA dataframe
int.GIA=data.frame()
models=unique(GIA$id)
for( i in models){
  print(i)
  iGIA=filter(GIA, GIA$id %in% c(i))
  for( i in 1:nrow(iGIA)){
    int.iGIA <- approx(iGIA$calBP,
                    iGIA$depth,
                    method= "linear",
                    xout=c(seq(from=min(iGIA$calBP),
                               to=max(iGIA$calBP),
                               by=50)))
    rGIA <- data.frame(calBP=int.iGIA$x,
                     depth=int.iGIA$y)
    rGIA$source <- iGIA$source[1]
    rGIA$type <- iGIA$type[1]
    rGIA$id <- iGIA$id[1]
    rGIA$region <- iGIA$region[1]
    rGIA$wgs_lat <- iGIA$wgs_lat[1]
    rGIA$wgs_lon <- iGIA$wgs_lon[1]
    rGIA$UTM31N_x <- iGIA$UTM31N_x[1]
    rGIA$UTM31N_y <- iGIA$UTM31N_y[1]
    }
  int.GIA <- rbind(int.GIA, rGIA)
}




int.GIA$id <- factor(int.GIA$id, levels=GIAid$id)
SLIP$id <- factor(SLIP$id, levels=unique(SLIP$id))
int.SLS <- rbind(int.GIA, SLIP)
int.SLS$id <- factor(int.SLS$id, levels=unique(int.SLS$id))
### PLOT all curves

ESL%>%
ggplot()+
  geom_line(aes(x=calBP, y=`Lambeck2014NS`, color="Lambeck 2014"), cex=1)+
  scale_color_manual(values="blue")+
  xlim(-16000,-7000)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", shape= "corrections")

int.GIA%>%
ggplot()+
  geom_line(aes(x=calBP, y=depth, group=id, color=id), cex=1)+
  scale_colour_manual(values=colorscale)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", shape= "corrections")
uGIA <- int.GIA

SLIP%>%
ggplot()+
  geom_point(aes(x=calBP, y=depth, group=id, shape=as.factor(type), color=id), cex=3)+
  scale_colour_manual(values=colorscale)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", shape= "corrections")

##################################################
#### MANUAL CURVE and CORRECTION SLIP CHECKER ####
##################################################

model_sel <- filter(GIAid, id %in%c(149, 1, 13, 24, 163, 19, 0.1))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% model_sel$id]

### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")



########################################
#### 0, 19 Doggerland ####
### 1. select ids to compare GIA output with selected slips

model_sel <- filter(GIAid, id %in%c(0, 0.1, 19, 19.1, 19.2, 161, 160))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% model_sel$id]

### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")


### 3.  select correction SLIP and curve
#save the unmodified curves as oGIA 
oGIA <- pGIA

# modify c0 to be between current 0 and 19 from 10k onwards
c0 <- pGIA %>% filter(id==0)
c19 <- pGIA %>% filter(id==19)
#select 0 in timeframe of 19
c0 <- c0%>%filter(calBP %in% c19$calBP)
# divide the difference and add this correction value
c <- (c19$depth-c0$depth)/2
c0$depth <- c0$depth+c 
#replace depth values in the main dataframe
int.SLS$depth[int.SLS$id==0 & int.SLS$calBP %in% c0$calBP] <- c0$depth
int.SLS <- subset(int.SLS, !(id==0 & calBP > -7000))


# create new c19 based on 0 and SLIPS 19.1 and 19.2
#take c0
c19 <- pGIA %>% filter(id==0)
#take c19 metadata
c19$wgs_lat <- pGIA$wgs_lat[pGIA$id==19][1]
c19$wgs_lon <- pGIA$wgs_lon[pGIA$id==19][1]
c19$UTM31N_x <-pGIA$UTM31N_x[pGIA$id==19][1]
c19$UTM31N_y <- pGIA$UTM31N_y[pGIA$id==19][1]


#calculate correction value c for 10.25 ka
cSLIP <- pSLIP %>% filter(calBP==-10250)
cGIA <- c19 %>% filter (calBP==-10250)
c<- cGIA$depth-cSLIP$depth
c19$depth <- c19$depth-c
c19$id <- factor(19, levels=levels(pGIA$id))
c19$source <- "HOLSEA, Kuchar 2012"

#remove c160 and c161 from dataset
int.SLS <- subset(int.SLS, !(id %in% c(19, 161, 160)))
int.SLS <- rbind(int.SLS, c19)


model_sel <- filter(GIAid, id %in%c(0, 0.1, 19, 19.1, 19.2))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% c(model_sel$id, oGIA$id)]

### 2. Final plot
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_line(aes(x=oGIA$calBP, y=oGIA$depth, group=as.factor(oGIA$id), color=as.factor(oGIA$id)), 
            linetype="dashed", cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")


########################################
#### 13 Oyster grounds ####
### 1. select ids to compare GIA output with selected slips

model_sel <- filter(GIAid, id %in%c(0, 13.1,  13.2,13))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% model_sel$id]

oGIA <- pGIA
### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")



c13 <- int.SLS%>%filter(id==0)
c13$wgs_lat <- int.GIA$wgs_lat[int.GIA$id==13][1]
c13$wgs_lon <- int.GIA$wgs_lon[int.GIA$id==13][1]
c13$UTM31N_x <-int.GIA$UTM31N_x[int.GIA$id==13][1]
c13$UTM31N_y <- int.GIA$UTM31N_y[int.GIA$id==13][1]

cSLIP <- pSLIP%>% filter(calBP==-10600)
cGIA <- c13%>% filter(calBP==-10600)
c=cSLIP$depth-cGIA$depth
c
c13$depth <- c13$depth+c
cGIA2 <- c13$depth[c13$calBP==-10000]
cGIA3 <- int.GIA$depth[int.GIA$id==13 & int.GIA$calBP==-10000]
c <- cGIA3-cGIA2
c
c13$depth[c13$calBP>-10000] <- int.GIA$depth[int.SLS$id==13 & int.SLS$calBP>-10000]-c
c13$id <- 13
int.SLS <- subset(int.SLS, !(id==13))
int.SLS <- rbind(int.SLS, c13)

model_sel <- filter(GIAid, id %in%c(0, 13.1,  13.2, 13))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% c(model_sel$id, oGIA$id)]

### 2. Final plot
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_line(aes(x=oGIA$calBP, y=oGIA$depth, group=as.factor(oGIA$id), color=as.factor(oGIA$id)), 
            linetype="dashed", cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")



########################################
#### 65  offshore Northeast Norfolk ####
### 1. select ids to compare GIA output with selected slips


model_sel <- filter(GIAid, id %in%c(165.1, 165.2,165, 13, 6))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% model_sel$id]
oGIA <- pGIA
### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

### 3.  select correction SLIP and curve

### 3.1 create correction values
cT <- pSLIP$calBP[pSLIP$type=="SLIP"] # timeslice
cD <- pSLIP$depth[pSLIP$type=="SLIP"] # depth SLIP
cD_GIA <- int.SLS$depth[int.SLS$id ==165 & int.SLS$calBP==cT] # depth curve
diff = cD-cD_GIA # difference between SLIP and curve
((cT*-1)/50) # steps between present and cT
mod = diff/((cT*-1)/50) # modification value

### 3.2 correct curve up to cT with diff
int.SLS$depth[int.SLS$calBP<=cT & 
                int.SLS$id ==165] <- int.SLS$depth[int.SLS$calBP<=cT & 
                                                        int.SLS$id ==165]+diff

### 3.3 correct curve from cT onwards with diff - mod * i 
# this is a decreasing value 
len <- (max(int.SLS$calBP[int.SLS$id == 165])-cT)/50
 for( i in 1:len){
  print(i)
  depths <- int.SLS$depth[int.SLS$calBP>cT& 
                            int.SLS$id == 165]
  iDepth <-depths[i]
  print(iDepth)
  ND=iDepth+diff-(mod*i)
  print(ND)
  int.SLS$depth[int.SLS$depth==iDepth &
                  int.SLS$id==165] <- ND
}


model_sel <- filter(GIAid, id %in%c(165.1, 165.2,165, 13, 6))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% c(model_sel$id, oGIA$id)]

### 2. Final plot
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_line(aes(x=oGIA$calBP, y=oGIA$depth, group=as.factor(oGIA$id), color=as.factor(oGIA$id)), 
            linetype="dashed", cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")


########################################
#### 122 - 127 SE Scotland - NE England  ####
### 1. select ids to compare GIA output with selected slips


model_sel <- filter(GIAid, id %in%c(122:127, 163))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% model_sel$id]
### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

int.GIA <- filter(int.SLS,type=="GIA model")
int.GIA <- int.GIA %>% filter(id %in% model_sel$id)
int.GIA <- int.GIA[order(-int.GIA$calBP),]
int.GIA <- int.GIA[order(as.numeric(int.GIA$id)),]

# The curve for SE scotland is used as a basis
sc22 <- filter(int.GIA, int.GIA$id==122)
# to run the script correctly timeslices should be ordered from -7000:-16000


for(m in model_sel$id[2:length(model_sel$id)]){ # for models 123-127
  print(m)
# select the target model
target <- filter(int.GIA, int.GIA$id==m)
#define the known min and max age
tmax <- max(target$calBP)
tmin <- min(target$calBP)
#calculate the difference between sc22 and the target model at tmax and tmin
diffmin <-  sc22$depth[sc22$calBP== tmin] - target$depth[target$calBP== tmin] # e.g. -8000
diffmax <-  sc22$depth[sc22$calBP== tmax] - target$depth[target$calBP== tmax] # e.g. -7000
# calculate the amount by which the difference increases each time slice
incr <- (diffmin-diffmax)/((tmax-tmin)/50)
x <- vector()
d <- sc22$depth

# for each timeslice in sc22
for( t in 1:length(sc22$calBP)){ 
  print(sc22$calBP[t])
  #calculate the new depth value for the corrected target curve, based on increased difference
  x[t] <- d[t]-(diffmax+(t*incr))
}
#corrected curve 
targetc <- sc22
targetc$depth <- x
targetc$depth[targetc$calBP>tmax] <- target$depth
targetc$source <- target$source[1]
targetc$id <- target$id[1]
targetc$region <- target$region[1]
targetc$wgs_lat <- target$wgs_lat[1]
targetc$wgs_lon <- target$wgs_lon[1]

int.GIA <- subset(int.GIA, !id==m)
int.GIA <- rbind(int.GIA, targetc)
}

pGIA <- int.GIA
pGIA <- pGIA%>%filter(id  %in% model_sel$id )
### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")


int.SLS <- int.SLS %>% filter(! id %in% int.GIA$id)
int.SLS <- rbind(int.SLS, int.GIA)
########################################
#### 137 - 164 SE England  ####
### 1. select ids to compare GIA output with selected slips

model_sel <- filter(GIAid, id %in%c(137:142, 146:149, 163, 164))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% model_sel$id]
### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

int.GIA <- filter(int.SLS,type=="GIA model")
int.GIA <- int.GIA %>% filter(id %in% model_sel$id)
int.GIA <- int.GIA[order(-int.GIA$calBP),]
int.GIA <- int.GIA[order(as.numeric(int.GIA$id)),]

# corrected curve 163 for offshore N Yorkshire is used as a basis
se63 <- filter(int.GIA, int.GIA$id==163)

for(m in model_sel$id[1:length(model_sel$id)]){ # for models 123-127
  print(m)
  # select the target model
  target <- filter(int.GIA, int.GIA$id==m)
  #define the known min and max age
  tmax <- max(target$calBP)
  tmin <- min(target$calBP)
  #calculate the difference between se63 and the target model at tmax and tmin
  diffmin <-  se63$depth[se63$calBP== tmin] - target$depth[target$calBP== tmin] # e.g. -8000
  diffmax <-  se63$depth[se63$calBP== tmax] - target$depth[target$calBP== tmax] # e.g. -7000
  # calculate the amount by which the difference increases each time slice
  incr <- (diffmin-diffmax)/((tmax-tmin)/50)
  x <- vector()
  d <- se63$depth

  # for each timeslice in se63
  for( t in 1:length(se63$calBP)){ 
    print(se63$calBP[t])
    #calculate the new depth value for the corrected target curve, based on increased difference
    x[t] <- d[t]-(diffmax+(t*incr))
  }
  #corrected curve 
  targetc <- se63
  targetc$depth <- x
  targetc$depth[targetc$calBP>tmax] <- target$depth
  targetc$source <- target$source[1]
  targetc$id <- target$id[1]
  targetc$region <- target$region[1]
  targetc$wgs_lat <- target$wgs_lat[1]
  targetc$wgs_lon <- target$wgs_lon[1]
  
  int.GIA <- subset(int.GIA, !id==m)
  int.GIA <- rbind(int.GIA, targetc)
}
### 2. plot to check the difference
pGIA=int.GIA
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

int.SLS <- int.SLS%>% filter(!id %in% int.GIA$id)
int.SLS <- rbind(int.SLS, int.GIA)
##########################################################################

#### 1 - 24 165 Southern Bight  ####
### 1. select ids to compare GIA output with selected slips

model_sel <- filter(GIAid, id %in%c(0,1:24, 165))
pSLS <- filter(int.SLS, int.SLS$id %in% model_sel$id)
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% model_sel$id]
### 2. plot to check the difference
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

int.GIA <- filter(int.SLS,type=="GIA model")
int.GIA <- int.GIA %>% filter(id %in% model_sel$id)
int.GIA <- int.GIA[order(-int.GIA$calBP),]
int.GIA <- int.GIA[order(as.numeric(int.GIA$id)),]

# corrected curve 163 for offshore N Yorkshire is used as a basis
db0 <- filter(int.GIA, int.GIA$id==0)

for(m in model_sel$id[1:length(model_sel$id)]){ # for models 123-127
  print(m)
  # select the target model
  target <- filter(int.GIA, int.GIA$id==m)
  #define the known min and max age
  tmax <- max(target$calBP)
  tmin <- min(target$calBP)
  #calculate the difference between db0 and the target model at tmax and tmin
  diffmin <-  db0$depth[db0$calBP== tmin] - target$depth[target$calBP== tmin] # e.g. -8000
  diffmax <-  db0$depth[db0$calBP== tmax] - target$depth[target$calBP== tmax] # e.g. -7000
  # calculate the amount by which the difference increases each time slice
  incr <- (diffmin-diffmax)/((tmax-tmin)/50)
  x <- vector()
  d <- db0$depth
  
  # for each timeslice in db0
  for( t in 1:length(db0$calBP)){ 
    print(db0$calBP[t])
    #calculate the new depth value for the corrected target curve, based on increased difference
    x[t] <- d[t]-(diffmax+(t*incr))
  }
  #corrected curve 
  targetc <- db0
  targetc$depth <- x
  targetc$depth[targetc$calBP>tmax] <- target$depth
  targetc$source <- target$source[1]
  targetc$id <- target$id[1]
  targetc$region <- target$region[1]
  targetc$wgs_lat <- target$wgs_lat[1]
  targetc$wgs_lon <- target$wgs_lon[1]
  
  int.GIA <- subset(int.GIA, !id==m)
  int.GIA <- rbind(int.GIA, targetc)
}
### 2. plot to check the difference
pGIA=int.GIA
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  geom_point(aes(x=pSLIP$calBP, y=pSLIP$depth, group=pSLIP$id, shape=as.factor(pSLIP$type), color=pSLIP$id), cex=2)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

int.SLS <- int.SLS%>% filter(!id %in% int.GIA$id)
int.SLS <- rbind(int.SLS, int.GIA)

##########################################################################

##########################################################################


pSLS <- int.SLS
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% unique(pGIA$id)]
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

#Vink
cGIA <- pGIA
pGIA <- subset(cGIA, id %in% c(0:23))
pcol <- colorscale[names(colorscale) %in% unique(pGIA$id)]
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

#Shennan Kuchar
pGIA <- subset(cGIA, id %in% c(0, 123:149, 164, 165))
pcol <- colorscale[names(colorscale) %in% unique(pGIA$id)]
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")


pGIA <- subset(cGIA, id %in% c( 165))
pcol <- colorscale[names(colorscale) %in% unique(pGIA$id)]
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  scale_colour_manual(values=pcol)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

library(tidyr)
cGIA$depth <- round(cGIA$depth, 2)

cGIA<- cGIA%>%arrange(calBP)%>%arrange(id)
path <- "cSLS.xlsx"
write.xlsx(cGIA,  file=path)
options(digits=7)
cGIA.p <- cGIA
cGIA.p$calBP=round(cGIA.p$calBP/1000,2)
cGIA.p$calBP <- format(cGIA.p$calBP, nsmall=2)
cGIA.p <- cGIA.p%>% pivot_wider(names_from = calBP, values_from = depth)
path <- "cSLS_p.xlsx"
write.xlsx(cGIA.p,  file=path)

cGIA10 <- cGIA%>%filter(calBP>-10000)
cGIA10$calBP <- (cGIA10$calBP/1000)
cGIA10$calBP <- format(cGIA10$calBP, nsmall=2)
cGIA10 <- cGIA10%>% pivot_wider(names_from = calBP, values_from = depth)
path <- "cSLS10.xlsx"
write.xlsx(cGIA10,  file=path)

cGIA250 <- cGIA%>%filter(calBP %in% seq(from=-16000, to=-7000, by =250))
cGIA250$calBP=cGIA250$calBP/1000
cGIA250.p <- cGIA250
cGIA250.p$calBP <- format(cGIA250.p$calBP, nsmall=2)
cGIA250.p <- cGIA250.p%>% pivot_wider(names_from = calBP, values_from = depth)
path <- "cSLS250_p.xlsx"
write.xlsx(cGIA250.p,  file=path)


###############################################################################
### FINAL FIGURE 4 layout
###############################################################################
GIAid <- GIAid%>%filter(type=="GIA model")
colorscale <- rgb(GIAid$r,GIAid$g, GIAid$b, GIAid$t)
names(colorscale) <-GIAid$id 
colorscale


ggplot()+geom_sf(data=world)+coord_sf(crs="+init=epsg:4326",
                                      xlim=c(-2.5, 9.5), ylim=c(50.5,56))+
  geom_point(aes(x=GIAid$wgs_lat, 
                 y=GIAid$wgs_lon,
                 shape=GIAid$type,
                 group=GIAid$id, 
                 color=GIAid$id), cex=3)+
  scale_colour_manual(values=colorscale)+
  geom_text(aes(x=GIAid$wgs_lat, 
                y=GIAid$wgs_lon,
                label=GIAid$id,
                vjust=1,
                hjust=1.5))+
  labs(x="Latitude",y="Longitude", color="GIA id", shape= "type")


### unmodified + Lambeck
  ggplot()+
  geom_line(aes(x=uGIA$calBP, y=uGIA$depth, group=uGIA$id, color=uGIA$id), cex=1)+
  scale_colour_manual(values=colorscale)+
  xlim(-12000,-7000)+
  ylim(-60,10)+
  labs(x="Years cal BP",y="m.s.l.", color="GIA id", shape= "corrections")+
  geom_line(aes(x=ESL$calBP, y=ESL$Lambeck2014NS), cex=1.5)


pSLS <- int.SLS
pGIA=pSLS[pSLS$type== "GIA model",]
pSLIP=pSLS[!pSLS$type== "GIA model",]
pcol <- colorscale[names(colorscale) %in% unique(pGIA$id)]
ggplot()+
  geom_line(aes(x=pGIA$calBP, y=pGIA$depth, group=pGIA$id, color=pGIA$id), cex=1)+
  scale_colour_manual(values=pcol)+
  xlim(-12000,-7000)+
  ylim(-60,10)+
  labs(x="Years cal BP",y="m.a.s.l.", color="GIA id", fill= "SLIP", shape= "corrections")

