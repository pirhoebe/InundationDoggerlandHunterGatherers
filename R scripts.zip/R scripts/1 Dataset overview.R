###############################################################################
# SI-4 radiocarbon workflow
# Hoebe, Cohen, Busschers, van Heteren & Peeters 2024
###############################################################################
#
# This SI consists of 6 main scripts that:
# 1 prepare the dataset
# 2 demonstrate the general temporal distribution in the dataset with aoristics
# 3 explore the impact of vetting on the spatiotemporal distribution
# 4 show the general frequency distribution through SPD and KDE
# 5 conduct the main analysis: modeltesting and permutation testing the SPDs
# 6 Conduct some additional calculations
#
# There are several supporting scripts that are called upon in the main script.
# These facilitate running certain functions and serve to declutter the scripts.
# The execution of these supporting scripts requires input parameters that are
# displayed with a message.
# these parameters have to be set manually if one wants to use the supporting 
# scripts separately.
#
# Pir Hoebe (p.w.hoebe@rug.nl), pirhoebe@gmail.com

###############################################################################
#### 1 Dataset preparation #### 
###############################################################################

# install and read relevant libraries
source(file="R scripts/read libraries.R")


# load data
data <- read_excel("data/sheets/data24cal.xlsx")
data_full <- data
lowerlim <- 12000
upperlim <- 7000
###############################################################################
#### 1.7 Data overview ####
###############################################################################
# As SPD aggregation includes data outside the timeframe to minimize edge 
# effects the number of dates within the timeframe is calculated here and used 
# for reference. The numbers are based on dates whose calibrated ranges
# overlap at least a year with the time frame. 
# Note: These numbers may vary based on the used calibration curve



# determine number of dates within timeframe for the full and vetted dataset
count <- list(full=list(dates=list(total=c(nrow(filter(data_full,
                                       data_full$calBP_end<=lowerlim &
                                         data_full$calBP_start>=upperlim))))))
###############################################################################
# Counting the distribution in the full dataset
# determine the number of dates by country
count$full$dates$country <- list(
  "EN" = nrow(filter(data_full,
                     data_full$calBP_end<=lowerlim &
                       data_full$calBP_start>=upperlim &
                       data_full$country=="Britain")),
  "BE" = nrow(filter(data_full,
                     data_full$calBP_end<=lowerlim &
                       data_full$calBP_start>=upperlim &
                       data_full$country=="Belgium")),
  "NL" = nrow(filter(data_full,
                     data_full$calBP_end<=lowerlim &
                       data_full$calBP_start>=upperlim &
                       data_full$country=="Netherlands")),
  "DE" = nrow(filter(data_full,
                     data_full$calBP_end<=lowerlim &
                       data_full$calBP_start>=upperlim &
                       data_full$country=="Germany")))

# determine the number of phases within the timeframe...
count$full$phases$total <- 
  length(unique(data_full$bins[data_full$calBP_end<=lowerlim &
                               data_full$calBP_start>=upperlim]))
# ... and phases by country
count$full$phases$country <- list(
  "EN" = length(unique(data_full$bins[data_full$calBP_end<=lowerlim &
                                        data_full$calBP_start>=upperlim&
                                        data_full$country=="Britain"])),
  "BE" = length(unique(data_full$bins[data_full$calBP_end<=lowerlim &
                                        data_full$calBP_start>=upperlim&
                                        data_full$country=="Belgium"])),
  "NL" = length(unique(data_full$bins[data_full$calBP_end<=lowerlim &
                                        data_full$calBP_start>=upperlim&
                                        data_full$country=="Netherlands"])),
  "DE" =length(unique(data_full$bins[data_full$calBP_end<=lowerlim &
                                       data_full$calBP_start>=upperlim &
                                       data_full$country=="Germany"]))
)
# determine the number of sites within the timeframe...
count$full$sites$total <- length(unique(
  data_full$sitename[data_full$calBP_end<=lowerlim &
                 data_full$calBP_start>=upperlim]))
# ...and sites by country
count$full$sites$country <- list(
  "EN" = length(unique(data_full$sitename[data_full$calBP_end<=lowerlim &
                                            data_full$calBP_start>=upperlim&
                                            data_full$country=="Britain"])),
  "BE" = length(unique(data_full$sitename[data_full$calBP_end<=lowerlim &
                                        data_full$calBP_start>=upperlim&
                                        data_full$country=="Belgium"])),
  "NL" = length(unique(data_full$sitename[data_full$calBP_end<=lowerlim &
                                        data_full$calBP_start>=upperlim&
                                        data_full$country=="Netherlands"])),
  "DE" =length(unique(data_full$sitename[data_full$calBP_end<=lowerlim &
                                       data_full$calBP_start>=upperlim &
                                       data_full$country=="Germany"]))
)
###############################################################################

###############################################################################
# transforming this overview to an exportable format
countdf <- data.frame(row.names=1:5)
countdf$selection <- NA_character_
countdf$country <- NA_character_
countdf$selection[1:5] <- "full"
countdf$country [1:5] <- c("Britain",  "Belgium", "Netherlands",
                           "Germany",  "Total")
countdf$n.dates <- NA_integer_
countdf$n.dates[1:4] <- unlist(count$full$dates$country, use.names=FALSE)
countdf$n.dates[5] <- sum(countdf$n.dates[1:4])


countdf$n.phases <- NA_integer_
countdf$n.phases[1:4] <- unlist(count$full$phases$country, use.names=FALSE)
countdf$n.phases[5] <- sum(countdf$n.phases[1:4])

countdf$n.sites <- NA_integer_
countdf$n.sites[1:4] <- unlist(count$full$sites$country, use.names=FALSE)
countdf$n.sites[5] <- sum(countdf$n.sites[1:4])


# the following numbers are called on for plotting in subsequent scripts
ndates <- list(full=count$full$dates$total, 
               vetted=count$vetted$dates$total, 
               c=count$full$dates$country)


###############################################################################
data <- data_full %>% filter(calBP_end<=lowerlim &
                               calBP_start>=upperlim)


path <- "output/data count overview.xlsx"
write.xlsx(countdf,  file=path)

save.image(file='14cEnvironment.RData')
message("Environment saved for use in SPD workflow and other scripts")

