
source('sitedata restructure EAA.R')
c14data <-read_excel("data/sheets/sites IM samples.xlsx")
# this data has elevation categories in the columns LM12.5k-LM7k
# obtained by point sampling the IM112 output with the data24cal dataset in QGIS
# categories are as follows:
# 1 water
# 2 saltmarsh
# 3 wetland
# 4 <20
# 5 <50
# 6 <100
# 7 < 250
# 8 <250+

# in this script we categorise eachdates according to elevation above past sea level
# this requires matching the date to the timestep corresponding to the appropriate
# elevation category column


# List of timeslices

slice <- rev(seq(from=7000, to=12000, by=250))


slicedata <- list()
c14dataL <- c14data
c14dataL$RLL <- NA
c14dataL$elevC <- NA
for (i in 1:21){
  df <-  c14dataL %>% filter(calBP_start<=slice[i] & calBP_start>(slice[i]-250)|
                               calBP_end<slice[i] & calBP_end>=(slice[i]-250))
  df$slice <- slice[i]
  slicedata[[i]] <- df
}

c14dataL[,35+1]

for (i in 1:21){
  slicedata[[i]]$RRL <- pull(slicedata[[i]][,33+i])
  # now categorise data within each timeslice according to RRL level
  slicedata[[i]]$elevC[slicedata[[i]]$RRL<=5] <- "low"
  # slicedata[[i]]$elevC[slicedata[[i]]$RRL<=6 & slicedata[[i]]$RRL>5] <- "mid"
  slicedata[[i]]$elevC[slicedata[[i]]$RRL>5] <- "high"}

# then combine all data from the different slices according to category
fdata <- slicedata[[1]]
for (i in 2:21){
  fdata <- rbind(fdata, slicedata[[i]])}



fdata <- fdata[,c(1:33, 57:61)] # remove LM columns
# then combine and remove duplicates per category
fdata <- fdata%>% filter(!is.na(elevC))

#fdata <- fdata_bu
fdata_bu <- fdata
fdata$RRL <- NULL

datalow <- fdata%>%filter(elevC=="low")
datahigh <- fdata%>%filter(elevC=="high")

datalow  <- filter(datalow, !duplicated(datalow$labcode))
datahigh  <- filter(datahigh, !duplicated(datahigh$labcode))

fdata_p <- rbind(datalow, 
                 # datamid, 
                 datahigh)

fdata_east <- fdata_p%>%filter(RA=="EAST")
data_e_low <- fdata_east%>%filter(elevC=="low")
data_e_high <- fdata_east%>%filter(elevC=="high")
fdata_west <- fdata_p%>%filter(RA=="WEST")
data_w_low <- fdata_west%>%filter(elevC=="low")
data_w_high <- fdata_west%>%filter(elevC=="high")
# calibrate
fdata_e.cal <- calibrate(
  x=fdata_east$c14age,
  errors=fdata_east$c14sd,
  dateDetails=fdata_east$sitename, 
  calCurves='intcal20',
  normalised=FALSE, 
  ncores=3)
fdata_e.cal$metadata$landscape <- fdata_east$elevC

fdata_e.cal$metadata$bins <- fdata_east$bins

fdata_w.cal <- calibrate(
  x=fdata_west$c14age,
  errors=fdata_west$c14sd,
  dateDetails=fdata_west$sitename, 
  calCurves='intcal20',
  normalised=FALSE, 
  ncores=3)
fdata_w.cal$metadata$landscape <- fdata_west$elevC

fdata_w.cal$metadata$bins <- fdata_west$bins

################################################################################
# east and west spd2rc
################################################################################
breaks <- seq(12000, 7000, -250)
timeRange <- c(12000, 7000)
data_east.spd <- spd(x = fdata_e.cal,
                     bins=fdata_e.cal$metadata$bins,
                     timeRange = timeRange)
data_west.spd <- spd(x = fdata_w.cal,
                     bins=fdata_w.cal$metadata$bins,
                     timeRange = timeRange)
data_east.spd2rc<- spd2rc(data_east.spd,
                          breaks = breaks)
data_west.spd2rc<- spd2rc(data_west.spd,
                          breaks = breaks)

# plot
######
par(mfrow=c(2,1), mar=c(1,1,1,5), las=0)

plot(data_east.spd2rc)
plot(data_west.spd2rc)

################################################################################
# permtest
################################################################################
perm.elevation_east=permTest(x=fdata_e.cal,
                             marks=fdata_e.cal$metadata$landscape,
                             bins = fdata_e.cal$metadata$bins,
                             timeRange=c(12000, 7000),
                             nsim=500,
                             runm=50)
perm.elevation_west=permTest(x=fdata_w.cal,
                             marks=fdata_w.cal$metadata$landscape,
                             bins = fdata_w.cal$metadata$bins,
                             timeRange=c(12000, 7000),
                             nsim=500,
                             runm=50)


# prep inundation model output 
# see inundation rate.R
IMCL <-read_excel("data/sheets/IMCL.xlsx")
IMrect <- IMCL%>%filter(IM %in% c("IM012", "IM112"))
IMrect <- IMrect%>%filter(ts>=-11750)
IMrect$ts <- IMrect$ts*-1
IM112 <- IMrect%>%filter(IM %in% c("IM112"))
IM012 <- IMrect%>%filter(IM %in% c("IM012"))
### this should be cleaned up for the final version 
IM012w <- read_csv("data/sheets/IM012 (w) combined_results.csv")
IM012w$CL <- NA
IM012w$CL[IM012w$value<=2] <- "water"
IM012w$CL[IM012w$value>2] <- "land"
IMCLw <- IM012w%>%filter(CL=="water")
IMCLw <- IMCLw%>%
  group_by(IM, ts, calBP)%>%
  summarise(count=sum(count), m2=sum(m2), km2=sum(km2))
IMCLw$ind <- NA
for(m in unique(IMCLw$IM)){
  print(m)
  model <- IMCLw[IMCLw$IM==m,]
  model[1, "ind"] <- model[1, "km2"]
  for(i in 2:nrow(model)){
    model[i, "ind"] <- model[i, "km2"]-model[i-1,"km2"]}
  IMCLw$ind[IMCLw$IM==m] <- model$ind
}
IM012w <- IMCLw%>%filter(calBP<=12000)

################################################################################
# WEST IM012
# permtest
################################################################################

###############################################################################
#plot
###############################################################################
lowerlim=12000
upperlim=7000

## Plot landscape zone permutation test ##
par(xpd=NULL)
###############################################################################
par(mfrow=c(4,1))
par(oma=c(3.5,5,2,2))
###############################################################################
# a inundation IM012
# plot water
par(mar=c(1.5,0,1.5,0))
par(xpd=NA)
#see inundation rate final.R
model <- IM012w
model <- model%>% filter(calBP>7000)
plot(x=model$ts,
     y=model$ind, 
     type="n", 
     xlim=c(12000,7000), 
     ylim=c(0, 20000), #max(model$ind+0.25*max(model$ind))),
     xlab=NA,
     ylab="km2 inundated",
     xaxs="i")
rect(x= model$calBP,
     xright = model$calBP-250,
     ybottom = 0,
     ytop = model$ind,
     col= "lightblue",
     border="black")
text(x=11900, y= 18000,#max(model$ind+0.15*max(model$ind)), 
     labels= paste("a. Inundation model (",model$IM[1],") west", sep=""), cex=1.5, adj=0)
axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
par(xpd=NA)
phaserect <- 5
phaselabels <- -0.2
source("R scripts/phaserect.R")
rm(phaselabels)
par(xpd=FALSE)

# a inundation IM012
# plot water
par(mar=c(1.5,0,1.5,0))
par(xpd=NA)
#see inundation rate final.R
model <- IM012w
model <- model%>% filter(calBP>7000)
plot(x=model$ts,
     y=model$ind, 
     type="n", 
     xlim=c(12000,7000), 
     ylim=c(0, 20000), #max(model$ind+0.25*max(model$ind))),
     xlab=NA,
     ylab="km2 inundated",
     xaxs="i")
rect(x= model$calBP,
     xright = model$calBP-250,
     ybottom = 0,
     ytop = model$ind,
     col= "lightblue",
     border="black")
text(x=11900, y= 18000,#max(model$ind+0.15*max(model$ind)), 
     labels= paste("b. Inundation model (",model$IM[1],") west", sep=""), cex=1.5, adj=0)
axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
par(xpd=NA)
phaserect <- 5
phaselabels <- -0.2
source("R scripts/phaserect.R")
rm(phaselabels)
par(xpd=FALSE)

###############################################################################
## b. Low ## 
par(mar=c(1.5,0,1.5,0))
plot(perm.elevation_west,focalm = "low",
     # ylab="Summed pobability",
     ylim=c(0,0.6))
par(xpd=NA)
text(labels= "Summed probability",x=12000, y=0.2,
     pos=2, offset=3.5, cex=1, srt=90)
par(xpd=FALSE)
text(x=12000, y=(par("usr")[4]-(0.2*(par("usr")[4]))), 
     labels=paste("c. Lowland radiocarbon dated sites: <50 m.a.s.l. \n(west, n=",
                  NROW(data_w_low), ")", sep = ""), 
     col="black", cex=1.5, pos=4)#font=2 for fat
axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)

axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
par(xpd=NA)
phaserect <- 5
source("R scripts/phaserect.R")
par(xpd=FALSE)
phaserect <- 6
source("R scripts/phaserect.R")

###############################################################################
## c. High ##
par(mar=c(1.5,0,1.5,0))
plot(perm.elevation_west,focalm = "high",
     ylim=c(0,0.6))
par(xpd=NA)
text(labels= "Summed probability",x=12000, y=0.2,
     pos=2, offset=3.5, cex=1, srt=90)
text(labels= "Years cal BP",x=9500, y=0,
     pos=1, offset=2.5, cex=1)
par(xpd=FALSE)
text(x=12000, y=(par("usr")[4]-(0.2*(par("usr")[4]))), 
     labels=paste("d. Inland radiocarbon dated sites: >=50 m.a.s.l. \n(west, n=",
                  NROW(data_w_high), ")", sep = ""), 
     col="black", cex=1.5, pos=4)
axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)

axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
par(xpd=NA)
phaserect <- 5
source("R scripts/phaserect.R")
par(xpd=FALSE)
phaserect <- 6
rm(phaselabels)
source("R scripts/phaserect.R")


################################################################################
# EAST IM112
# permtest
################################################################################

###############################################################################
#plot
###############################################################################
lowerlim=12000
upperlim=7000

## Plot landscape zone permutation test ##
par(xpd=NULL)
###############################################################################
par(mfrow=c(4,1))
par(oma=c(3.5,5,2,2))
###############################################################################
# a inundation IM012
# plot water
par(mar=c(1.5,0,1.5,0))
par(xpd=NA)
model <- IM012
plot(x=model$ts,
     y=model$ind, 
     type="n", 
     xlim=c(12000,7000), 
     ylim=c(0, 20000),#max(IMCL$ind+0.25*max(IMCL$ind))),
     xlab=NA,
     ylab="km2 inundated",
     xaxs="i")
rect(x= model$ts,
     xright = model$ts+250,
     ybottom = 0,
     ytop = model$ind,
     col= "lightblue",
     border="black")
text(x=11900, y= 18000,#max(IMCL$ind+0.15*max(IMCL$ind)), 
     labels= paste("e. Inundation model (",model$IM[1],") east", sep=""), cex=1.5, adj=0)
axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
par(xpd=NA)
phaserect <- 5
phaselabels <- -0.2
source("R scripts/phaserect.R")
rm(phaselabels)
par(xpd=FALSE)
###############################################################################
# b inundation IM112
  # plot water
  par(mar=c(1.5,0,1.5,0))
  par(xpd=NA)
  model <- IM112
  plot(x=model$ts,
       y=model$ind, 
       type="n", 
       xlim=c(12000,7000), 
       ylim=c(0, 20000),# max(IMCL$ind+0.25*max(IMCL$ind))),
       xlab=NA,
       ylab="km2 inundated",
       xaxs="i")
  rect(x= model$ts,
       xright = model$ts+250,
       ybottom = 0,
       ytop = model$ind,
       col= "lightblue",
       border="black")
  text(x=11900, y= 18000,#max(IMCL$ind+0.15*max(IMCL$ind)), 
       labels= paste("f. Inundation model (",model$IM[1],") east", sep=""), cex=1.5, adj=0)
  axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
  axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
  axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
  axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
  axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
  axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
  par(xpd=NA)
  phaserect <- 5

  source("R scripts/phaserect.R")
  rm(phaselabels)
  par(xpd=FALSE)

###############################################################################
## c. Low ## 
par(mar=c(1.5,0,1.5,0))
plot(perm.elevation_east,focalm = "low",
     # ylab="Summed pobability",
     ylim=c(0,0.6))
par(xpd=NA)
text(labels= "Summed probability",x=12000, y=0.7,
     pos=2, offset=3.5, cex=1, srt=90)
par(xpd=FALSE)
text(x=12000, y=(par("usr")[4]-(0.2*(par("usr")[4]))), 
     labels=paste("g. Lowland radiocarbon dated sites: <50 m.a.s.l. \n(east, n=",
                  NROW(data_e_low), ")", sep = ""), 
     col="black", cex=1.5, pos=4)#font=2 for fat
axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)

axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
par(xpd=NA)
phaserect <- 5
source("R scripts/phaserect.R")
par(xpd=FALSE)
phaserect <- 6
source("R scripts/phaserect.R")

###############################################################################
## d. High ##
par(mar=c(1.5,0,1.5,0))
plot(perm.elevation_east,focalm = "high",
     ylim=c(0,0.6))
par(xpd=NA)
text(labels= "Summed probability",x=12000, y=0.7,
     pos=2, offset=3.5, cex=1, srt=90)
text(labels= "Years cal BP",x=9500, y=0,
     pos=1, offset=2.5, cex=1)
par(xpd=FALSE)
text(x=12000, y=(par("usr")[4]-(0.2*(par("usr")[4]))), 
     labels=paste("h. Inland radiocarbon dated sites: >=50 m.a.s.l. \n(east, n=",
                  NROW(data_e_high), ")", sep = ""), 
     col="black", cex=1.5, pos=4)
axis(3, at = seq(7000,12000, by=1000), labels = FALSE)
axis(3, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)

axis(1, at = seq(7000,12000, by=1000), labels = FALSE)
axis(1, at = seq(7000,12000, by=100),labels=FALSE, tck=-0.02)
axis(1, at = seq(7000,12000, by=500),labels=FALSE, tck=-0.03)
par(xpd=NA)
phaserect <- 5
source("R scripts/phaserect.R")
par(xpd=FALSE)
phaserect <- 6
rm(phaselabels)
source("R scripts/phaserect.R")

# number of dates
NROW(c14data)
NROW(fdata_east)
NROW(data_e_low )
NROW(data_e_high )
NROW(fdata_west )
NROW(data_w_low )
NROW(data_w_high )

# number of phases
NROW(unique(c14data$bins))
NROW(unique(fdata_east$bins))
NROW(unique(data_e_low$bins))
NROW(unique(data_e_high$bins))
NROW(unique(fdata_west$bins))
NROW(unique(data_w_low$bins))
NROW(unique(data_w_high$bins))

# number of sites
NROW(unique(c14data$sitename))
NROW(unique(fdata_east$sitename))
NROW(unique(data_e_low$sitename))
NROW(unique(data_e_high$sitename))
NROW(unique(fdata_west$sitename))
NROW(unique(data_w_low$sitename))
NROW(unique(data_w_high$sitename))
