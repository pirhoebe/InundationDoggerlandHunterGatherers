library(readr)
library(readxl)
library(dplyr)
library(tidyr)
IMCL <- read_excel("data/sheets/IMCL.xlsx")
IMCL$IM <- factor(c(IMCL$IM), levels=c( "IM000",
                                        "IM010",
                                        "IM011",
                                        "IM012",
                                        "IM100",
                                        "IM110",
                                        "IM111",
                                        "IM112"))



IMlist <- factor(c(IMCL$IM), levels=c( "IM000",
                                       "IM010",
                                       "IM011",
                                       "IM012",
                                       "IM100",
                                       "IM110",
                                       "IM111",
                                       "IM112"))
IMlist=sort(unique(IMlist))

par(mfrow=c(4,2))
par(oma=c(3.5,1,2,0))
for(m in IMlist){
  print(m)
  model <- IMCL[IMCL$IM==m,]
  # plot water
  
  par(mar=c(1.5,4,1,1))
  par(xpd=NA)
  plot(x=model$ts,
       y=model$ind, 
       type="n", 
       xlim=c(-12000,-7000), 
       ylim=c(0, max(IMCL$ind+0.1*max(IMCL$ind))),
       xlab=NA,
       ylab="km2 inundated")
  rect(x= model$ts,
       xright = model$ts-250,
       ybottom = 0,
       ytop = model$ind,
       col= "lightblue",
       border="black")
  text(x=-12000, y= max(IMCL$ind), labels= model$IM[1], cex=2, adj=0)
  axis(1, at = seq(-11000,-7000, by=2000), labels = FALSE, tck=-0.05)
  axis(1, at = seq(-12000,-7000, by=500), labels = FALSE, tck=-0.03)
  axis(1, at = seq(-12000,-7000, by=250), labels = FALSE, tck=-0.015)
  axis(3, at = seq(-11000,-7000, by=2000), labels = FALSE, tck=-0.05)
  axis(3, at = seq(-12000,-7000, by=500), labels = FALSE, tck=-0.03)
  axis(3, at = seq(-12000,-7000, by=250), labels = FALSE, tck=-0.015) 
  
}


