###############################################################################
#### 4 Frequency distribution ####
###############################################################################
# install and read relevant libraries
source(file="R scripts/read libraries.R")


data <- read_excel("data/sheets/data24cal.xlsx")
data_full <- data
lowerlim <- 12000
upperlim <- 7000



# PARAMETERS 
ncores <- 3 # set the number of processor cores that you want to set to work.
curve <- "intcal20"
normalised <- FALSE # turn of redundant normalisation

# calibration
set <- data_full
source("R scripts/calibrate data.R")
data_full.cal <- set.cal
rm(set, set.cal)

# Unfortunately rcarbon does not seem to support adding binsense to other plots
# save plot to add the plot with other software. Figure margins here work well 
# if the multiplot below is saved at 1000 x 1000.

png(file="binsense.png",
    width=1230, height=300)
set.cal <- data_full.cal
binsense(x=set.cal,
         y=set.cal$metadata$site_id,
         h=c(50,100,200,500),
         timeRange=c(lowerlim, upperlim),
         calendar = "BP")
dev.off()

h_value <- 100 # h of 100 assigns dates from the same site that are within 100y
# of each other into the same bin 

#full dataset
data_full$bins = binPrep(sites=data_full$site_id,
                         ages=data_full$c14age, 
                         h=h_value)


# PARAMETERS 
runningmean <- 50
lowerlim <- 12500
upperlim <- 6500
normalised <- FALSE

### Full dataset SPD aggregation ###
if(exists("data_full.spd")==FALSE){
  bins = data_full$bins
  set.cal <- data_full.cal
  set.spd= spd(set.cal,timeRange=c(lowerlim,upperlim), bins = bins)
  data_full.spd <- set.spd
}

### Full dataset SPD normalised ###
if(exists("data_full_n.cal")==FALSE){
  normalised <- TRUE
  set <- data_full
  source("R scripts/calibrate data.R")
  data_full_n.cal <- set.cal
  normalised <- FALSE}

if(exists("data_full_n.spd")==FALSE){
  bins = data_full$bins
  set.cal <- data_full_n.cal
  set.spd= spd(set.cal,timeRange=c(lowerlim,upperlim), bins = bins)
  data_full_n.spd <- set.spd
}

sWest <- data_full%>% filter(RA=="WEST")
sWest <- sWest%>% select(site_id, sitename, RA)
sWest <- unique(sWest)
data_West <- data_full%>%filter(RA=="WEST")
normalised <- FALSE
set <- data_West
source("R scripts/calibrate data.R")
data_West.cal <- set.cal

sEast <- data_full%>% filter(RA=="EAST")
sEast <- sEast%>% select(site_id, sitename, RA)
sEast <- unique(sEast)
data_East <- data_full%>%filter(RA== "EAST")
normalised <- FALSE
set <- data_East
source("R scripts/calibrate data.R")
data_East.cal <- set.cal


### Full dataset KDE ###
# PARAMETERS 
simulations=500

# 50
bandwidth=50
bins = data_full$bins
set.cal <- data_full.cal
message("sampling kernels...")
set.randates = sampleDates(set.cal,
                           bins=bins,
                           nsim=simulations,
                           verbose=FALSE,
                           boot = TRUE)
message("Kernel Density Estimate...")
set.ckde = ckde(set.randates,timeRange=c(lowerlim,upperlim),bw=bandwidth)
data_full.kde50 <- set.ckde

# West
bandwidth=50
bins = data_West$bins
set.cal <- data_West.cal
message("sampling kernels...")
set.randates = sampleDates(set.cal,
                           bins=bins,
                           nsim=simulations,
                           verbose=FALSE,
                           boot = TRUE)
message("Kernel Density Estimate...")
set.ckde = ckde(set.randates,timeRange=c(lowerlim,upperlim),bw=bandwidth)
data_West.kde50 <- set.ckde

# East
bandwidth=50
bins = data_East$bins
set.cal <- data_East.cal
message("sampling kernels...")
set.randates = sampleDates(set.cal,
                           bins=bins,
                           nsim=simulations,
                           verbose=FALSE,
                           boot = TRUE)
message("Kernel Density Estimate...")
set.ckde = ckde(set.randates,timeRange=c(lowerlim,upperlim),bw=bandwidth)
data_East.kde50 <- set.ckde

# 100
bandwidth=100
bins = data_full$bins
set.cal <- data_full.cal
message("sampling kernels...")
set.randates = sampleDates(set.cal,
                           bins=bins,
                           nsim=simulations,
                           verbose=FALSE,
                           boot = TRUE)
message("Kernel Density Estimate...")
set.ckde = ckde(set.randates,timeRange=c(lowerlim,upperlim),bw=bandwidth)
data_full.kde100 <- set.ckde



### load intcal20 data ####
intcal20 <- read.csv('https://www.intcal.org/curves/intcal20.14c',
                     encoding="UTF-8",skip=11,header=F)
colnames(intcal20) <- c("BP","CRA","Error","D14C","Sigma")

### load NGRIP data ###
if(!require('pangaear')) install.packages('pangaear')
if(!"pangaear" %in% (.packages())){library(pangaear)} else 
{message(paste("pangear is attached"))}
NGRIP<- pg_data(doi='10.1594/PANGAEA.824889')
NGRIPdata <- NGRIP[[1]]$data 
NGRIPdata <- rename(NGRIPdata, age = 2)
NGRIPdata <- rename(NGRIPdata, d18O = 3)
NGRIPdata$calBP <-NGRIPdata$age*1000 
NGRIPdata$calBP <- round(NGRIPdata$calBP, 0)
NGRIPdata <- NGRIPdata %>% filter(calBP>=upperlim & calBP<=lowerlim)
NGRIPdata$age <- NULL

### climate phases ###
# prepare cold climate phases as following Rasmussen et al. 2014 
# and 10.3ka (Bond et al 2001)
event <- data.frame(name=c("GS-1", "11.4ka\nevent", "10.3ka\nevent", 
                           "9.3ka\nevent", "8.2ka\nevent"), 
                    start=c( lowerlim, 
                            11470, 10375,  9300, 8250), 
                    end=c( 11653, 11350, 10225,  9190, 8090))
event$centre <- event$start-((event$start-event$end)/2)


chronozones <- data.frame(row.names=1:5)
chronozones$name <- c("Younger Dryas", "Preboreal", "Early Boreal", "Late Boreal", "Atlantic")
chronozones$llim <- c( lowerlim, 11653, 10800, 9190, 8090)
chronozones$ulim <- c( 11653, 10800, 9190, 8090, upperlim)
chronozones$col <- c(rgb(0,0,0,alpha=0.2), "palegreen3", "palegreen4", 
                     "palegreen4", "green4")
###############################################################################
#### PLOTTING
###############################################################################
### KDE 50: Full, West, East y bw ###
upperlim=7000
lowerlim=12000
par(mfrow=c(3,1))
par(yaxs="i")
par(xaxs="i")
par(oma=c(4,0,4,0))
###############################################################################
par(mar=c(1.5,6,1.5,2))
plot(data_full.kde50,
     xaxt="n",
     xlim=c(lowerlim,upperlim))
source("R scripts/phaserect.R")
text(x= lowerlim, y=par("usr")[4]-(0.1*par("usr")[4]),
     labels="a. Research Area", col="black", cex=1.5, font=2, pos=4)
axis(1, at = seq(9000,(lowerlim-1000), by=2000))
# ticks on top axis
axis(3, at = seq(8000,lowerlim, by=1000))
axis(3, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.02)
axis(3, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.03)
# ticks on middle axis
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=0.01)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.02)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=0.02)
axis(1, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=0.025)
axis(1, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=-0.025)
###############################################################################
par(mar=c(1.5,6,1.5,2))
plot(data_West.kde50,
     xlim=c(lowerlim,upperlim))
source("R scripts/phaserect.R")
text(x= lowerlim, y=par("usr")[4]-(0.1*par("usr")[4]),
     labels="b. West (England)", col="black", cex=1.5, font=2, pos=4)
axis(1, at = seq(9000,(lowerlim-1000), by=2000))
# ticks on middle axis top
axis(3, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(3, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=0.01)
axis(3, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.02)
axis(3, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=0.02)
axis(3, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=0.025)
axis(3, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=-0.025)
# ticks on middle axis bottom
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=0.01)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.015)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=0.015)
axis(1, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=0.025)
axis(1, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=-0.025)
###############################################################################
par(mar=c(1.5,6,1.5,2))
plot(data_East.kde50,
     xaxt="n",
     xlim=c(lowerlim,upperlim))
source("R scripts/phaserect.R")
text(x= lowerlim, y=par("usr")[4]-(0.1*par("usr")[4]),
     labels="c. East (BE, NL, DE)", col="black", cex=1.5, font=2, pos=4)
axis(1, at = seq(9000,(lowerlim-1000), by=2000))
# ticks on middle axis top
axis(3, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(3, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=0.01)
axis(3, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.02)
axis(3, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=0.02)
axis(3, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=0.025)
axis(3, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=-0.025)

# ticks on middle axis bottom
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=-0.01)
axis(1, at = seq(upperlim,lowerlim, by=100),labels=FALSE, tck=0.01)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=-0.015)
axis(1, at = seq(upperlim,lowerlim, by=500),labels=FALSE, tck=0.015)
axis(1, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=0.025)
axis(1, at = seq(8000,lowerlim, by=1000), labels=FALSE, tck=-0.025)

